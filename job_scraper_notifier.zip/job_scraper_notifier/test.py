import requests
import pandas as pd
import numpy as np
from bs4 import BeautifulSoup
import smtplib
import schedule

print("All libraries installed successfully!")
